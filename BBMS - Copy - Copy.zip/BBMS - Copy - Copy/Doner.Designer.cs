﻿namespace BBMS
{
    partial class Doner
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            panel3 = new Panel();
            label2 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            label10 = new Label();
            DNameTb = new TextBox();
            DAgeTb = new TextBox();
            DPhoneTb = new TextBox();
            DGenCb = new ComboBox();
            DBGroupCb = new ComboBox();
            DDeseaseTb = new TextBox();
            DAddressTb = new TextBox();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label18 = new Label();
            label11 = new Label();
            button1 = new Button();
            button2 = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Red;
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(label2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(251, 767);
            panel1.TabIndex = 1;
            panel1.Paint += panel1_Paint;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Red;
            label9.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(81, 695);
            label9.Name = "label9";
            label9.Size = new Size(110, 32);
            label9.TabIndex = 17;
            label9.Text = "Logout";
            label9.Click += label9_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Red;
            label8.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(45, 106);
            label8.Name = "label8";
            label8.Size = new Size(166, 32);
            label8.TabIndex = 15;
            label8.Text = "Dashboard";
            label8.Click += label8_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Red;
            label7.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(45, 496);
            label7.Name = "label7";
            label7.Size = new Size(180, 32);
            label7.TabIndex = 13;
            label7.Text = "Blood Stock";
            label7.Click += label7_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Red;
            label6.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(45, 426);
            label6.Name = "label6";
            label6.Size = new Size(200, 32);
            label6.TabIndex = 11;
            label6.Text = "Search Blood";
            label6.Click += label6_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Red;
            label5.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(45, 357);
            label5.Name = "label5";
            label5.Size = new Size(203, 32);
            label5.TabIndex = 9;
            label5.Text = "Recipient List";
            label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Red;
            label4.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(45, 291);
            label4.Name = "label4";
            label4.Size = new Size(146, 32);
            label4.TabIndex = 7;
            label4.Text = "Recipient";
            label4.Click += label4_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Red;
            label3.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(46, 226);
            label3.Name = "label3";
            label3.Size = new Size(162, 32);
            label3.TabIndex = 5;
            label3.Text = "Donor  List";
            label3.Click += label3_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Brown;
            panel3.Location = new Point(27, 166);
            panel3.Name = "panel3";
            panel3.Size = new Size(12, 32);
            panel3.TabIndex = 2;
            panel3.Paint += panel3_Paint;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Red;
            label2.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(45, 166);
            label2.Name = "label2";
            label2.Size = new Size(105, 32);
            label2.TabIndex = 3;
            label2.Text = "Donor ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Red;
            label1.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(219, 9);
            label1.Name = "label1";
            label1.Size = new Size(464, 32);
            label1.TabIndex = 2;
            label1.Text = "Blood Bank Management System";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Red;
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(251, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(893, 55);
            panel2.TabIndex = 2;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.White;
            label10.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = Color.Red;
            label10.Location = new Point(549, 76);
            label10.Name = "label10";
            label10.Size = new Size(281, 32);
            label10.TabIndex = 4;
            label10.Text = "Donor  Registration";
            // 
            // DNameTb
            // 
            DNameTb.BorderStyle = BorderStyle.FixedSingle;
            DNameTb.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            DNameTb.Location = new Point(300, 207);
            DNameTb.Name = "DNameTb";
            DNameTb.Size = new Size(160, 30);
            DNameTb.TabIndex = 6;
            DNameTb.TextChanged += DNameTb_TextChanged;
            // 
            // DAgeTb
            // 
            DAgeTb.BorderStyle = BorderStyle.FixedSingle;
            DAgeTb.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            DAgeTb.Location = new Point(573, 207);
            DAgeTb.Name = "DAgeTb";
            DAgeTb.Size = new Size(177, 30);
            DAgeTb.TabIndex = 8;
            DAgeTb.TextChanged += DAgeTb_TextChanged;
            // 
            // DPhoneTb
            // 
            DPhoneTb.BorderStyle = BorderStyle.FixedSingle;
            DPhoneTb.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            DPhoneTb.Location = new Point(300, 357);
            DPhoneTb.Name = "DPhoneTb";
            DPhoneTb.Size = new Size(160, 30);
            DPhoneTb.TabIndex = 11;
            // 
            // DGenCb
            // 
            DGenCb.FormattingEnabled = true;
            DGenCb.Location = new Point(892, 207);
            DGenCb.Name = "DGenCb";
            DGenCb.Size = new Size(160, 28);
            DGenCb.TabIndex = 13;
            DGenCb.SelectedIndexChanged += DGenCb_SelectedIndexChanged;
            // 
            // DBGroupCb
            // 
            DBGroupCb.FormattingEnabled = true;
            DBGroupCb.Location = new Point(573, 357);
            DBGroupCb.Name = "DBGroupCb";
            DBGroupCb.Size = new Size(177, 28);
            DBGroupCb.TabIndex = 14;
            DBGroupCb.SelectedIndexChanged += DBGroupCb_SelectedIndexChanged;
            // 
            // DDeseaseTb
            // 
            DDeseaseTb.BorderStyle = BorderStyle.FixedSingle;
            DDeseaseTb.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            DDeseaseTb.Location = new Point(892, 355);
            DDeseaseTb.Name = "DDeseaseTb";
            DDeseaseTb.Size = new Size(160, 30);
            DDeseaseTb.TabIndex = 16;
            DDeseaseTb.TextChanged += DDeseaseTb_TextChanged;
            // 
            // DAddressTb
            // 
            DAddressTb.BorderStyle = BorderStyle.FixedSingle;
            DAddressTb.Font = new Font("Century Gothic", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            DAddressTb.Location = new Point(573, 520);
            DAddressTb.Name = "DAddressTb";
            DAddressTb.Size = new Size(257, 30);
            DAddressTb.TabIndex = 18;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(300, 164);
            label12.Name = "label12";
            label12.Size = new Size(71, 25);
            label12.TabIndex = 35;
            label12.Text = "Name";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label13.Location = new Point(573, 164);
            label13.Name = "label13";
            label13.Size = new Size(50, 25);
            label13.TabIndex = 36;
            label13.Text = "Age";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label14.Location = new Point(892, 164);
            label14.Name = "label14";
            label14.Size = new Size(88, 25);
            label14.TabIndex = 37;
            label14.Text = "Gender";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label15.Location = new Point(300, 311);
            label15.Name = "label15";
            label15.Size = new Size(95, 25);
            label15.TabIndex = 38;
            label15.Text = "Contact";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label16.Location = new Point(573, 311);
            label16.Name = "label16";
            label16.Size = new Size(144, 25);
            label16.TabIndex = 39;
            label16.Text = "Blood Group";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label18.Location = new Point(573, 473);
            label18.Name = "label18";
            label18.Size = new Size(94, 25);
            label18.TabIndex = 41;
            label18.Text = "Address";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Century Schoolbook", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label11.Location = new Point(892, 311);
            label11.Name = "label11";
            label11.Size = new Size(94, 25);
            label11.TabIndex = 42;
            label11.Text = "Desease";
            // 
            // button1
            // 
            button1.BackColor = Color.LightSalmon;
            button1.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(429, 644);
            button1.Name = "button1";
            button1.Size = new Size(185, 44);
            button1.TabIndex = 43;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.LightSalmon;
            button2.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point);
            button2.Location = new Point(749, 644);
            button2.Name = "button2";
            button2.Size = new Size(185, 44);
            button2.TabIndex = 44;
            button2.Text = "Clear";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // Doner
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1144, 767);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label11);
            Controls.Add(label18);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(DAddressTb);
            Controls.Add(DDeseaseTb);
            Controls.Add(DBGroupCb);
            Controls.Add(DGenCb);
            Controls.Add(DPhoneTb);
            Controls.Add(DAgeTb);
            Controls.Add(DNameTb);
            Controls.Add(label10);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Doner";
            Text = "Doner";
            Load += Doner_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label2;
        private Label label1;
        private Panel panel2;
        private Panel panel3;
        private Label label10;
        private TextBox DNameTb;
        private TextBox DAgeTb;
        private TextBox DPhoneTb;
        private ComboBox DGenCb;
        private ComboBox DBGroupCb;
        private TextBox DDeseaseTb;
        private TextBox DAddressTb;
        private Label label3;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label18;
        private Label label11;
        private Button button1;
        private Button button2;
    }
}