﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class Bloodstock : Form
    {
        public Bloodstock()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Doner doner = new Doner();
            doner.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            DonorList dl = new DonorList();
            dl.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Recipient recipient = new Recipient();
            recipient.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            RecipientList recipientList = new RecipientList();
            recipientList.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SearchBlood searchblood = new SearchBlood();
            searchblood.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
