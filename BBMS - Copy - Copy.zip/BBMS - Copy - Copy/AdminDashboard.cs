﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class AdminDashboard : Form
    {
        public AdminDashboard()
        {
            InitializeComponent();
            GetData();
        }

        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\ADMIN\Documents\BBMSDb.mdf;Integrated Security=True;Connect Timeout=30");
        private void GetData()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count(*) from DonorTbl", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            DonorLbl.Text = dt.Rows[0][0].ToString();

            SqlDataAdapter sda1 = new SqlDataAdapter("Select count(*) from RecipientTbl", con);
            DataTable dt1 = new DataTable();
            sda1.Fill(dt1);
            RecipientLbl.Text = dt1.Rows[0][0].ToString();

            SqlDataAdapter sda2 = new SqlDataAdapter("Select count(*) from UserTbl", con);
            DataTable dt2 = new DataTable();
            sda2.Fill(dt2);
            UserLbl.Text = dt2.Rows[0][0].ToString();

            SqlDataAdapter sda3 = new SqlDataAdapter("Select count(*) from BloodTbl", con);
            DataTable dt3 = new DataTable();
            sda3.Fill(dt3);
            int BStock = Convert.ToInt32(dt3.Rows[0][0].ToString());
            TotalLbl.Text = "" + BStock;

            SqlDataAdapter sda4 = new SqlDataAdapter("Select count(*) from BloodTbl where BGroup='" + "O+" + "'", con);
            DataTable dt4 = new DataTable();
            sda4.Fill(dt4);
            OPlusNumLbl.Text = dt4.Rows[0][0].ToString();
            double OPlusPercentage = (Convert.ToDouble(dt4.Rows[0][0].ToString()) / BStock) * 100;
            OPlusProgress.Value = Convert.ToInt32(OPlusPercentage);

            SqlDataAdapter sda5 = new SqlDataAdapter("Select count(*) from BloodTbl where BGroup='" + "AB+" + "'", con);
            DataTable dt5 = new DataTable();
            sda5.Fill(dt5);
            ABPlusNumLbl.Text = dt5.Rows[0][0].ToString();
            double ABPlusPercentage = (Convert.ToDouble(dt5.Rows[0][0].ToString()) / BStock) * 100;
            ABPlusProgress.Value = Convert.ToInt32(ABPlusPercentage);

            SqlDataAdapter sda6 = new SqlDataAdapter("Select count(*) from BloodTbl where BGroup='" + "A+" + "'", con);
            DataTable dt6 = new DataTable();
            sda6.Fill(dt6);
            APlusNumLbl.Text = dt6.Rows[0][0].ToString();
            double APlusPercentage = (Convert.ToDouble(dt6.Rows[0][0].ToString()) / BStock) * 100;
            APlusProgress.Value = Convert.ToInt32(APlusPercentage);

            SqlDataAdapter sda7 = new SqlDataAdapter("Select count(*) from BloodTbl where BGroup='" + "B+" + "'", con);
            DataTable dt7 = new DataTable();
            sda7.Fill(dt7);
            BPlusNumLbl.Text = dt7.Rows[0][0].ToString();
            double BPlusPercentage = (Convert.ToDouble(dt7.Rows[0][0].ToString()) / BStock) * 100;
            BPlusProgress.Value = Convert.ToInt32(BPlusPercentage);
            con.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

            AdminMRL rl = new AdminMRL();
            rl.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {
        }

        private void DonorLbl_Click(object sender, EventArgs e)
        {
        }

        private void guna2GradientPanel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void guna2GradientPanel2_Paint(object sender, PaintEventArgs e)
        {
        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            AdminMDL dl = new AdminMDL();
            dl.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {

            AdminMSB bs = new AdminMSB();
            bs.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Hide();
        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {

        }
    }
}
