﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BBMS
{
    public partial class Doner : Form
    {
        public Doner()
        {
            InitializeComponent();
            //GetData();

            // DGenCb = new ComboBox();
            DGenCb.Items.Add("Male");
            DGenCb.Items.Add("Female");
            DGenCb.Items.Add("Other");
            // DGenCb.DropDownStyle = ComboBoxStyle.DropDownList; // To prevent user input
            //DGenCb.SelectedIndexChanged += DGenCb.SelectedIndexChanged;

            //Controls.Add(DGenCb);
            DGenCb.SelectedIndex = 0;


            DBGroupCb.Items.Add("A+");
            DBGroupCb.Items.Add("A-");
            DBGroupCb.Items.Add("B+");
            DBGroupCb.Items.Add("B-");
            DBGroupCb.Items.Add("AB+");
            DBGroupCb.Items.Add("AB-");
            DBGroupCb.Items.Add("O+");
            DBGroupCb.Items.Add("O-");

            DBGroupCb.SelectedIndex = 0;

        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\BloodBankManagDB.mdf;Integrated Security=True;Connect Timeout=30");
        private void Reset()
        {
            DNameTb.Text = "";
            DAgeTb.Text = "";
            DPhoneTb.Text = "";
            DAddressTb.Text = "";
            DDeseaseTb.Text = "";
            DGenCb.SelectedIndex = -1;
            DBGroupCb.SelectedIndex = -1;

        }

        private void Doner_Load(object sender, EventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (DNameTb.Text == "" || DPhoneTb.Text == "" || DAgeTb.Text == "" || DGenCb.SelectedIndex == -1 || DBGroupCb.SelectedIndex == -1 || DDeseaseTb.Text == "" || DAddressTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    string query = "insert into DonorTbl values('" + DNameTb.Text + "','" + DAgeTb.Text + "','" + DGenCb.SelectedItem.ToString() + "','" + DPhoneTb.Text + "','" + DAddressTb.Text + "','" + DBGroupCb.SelectedItem.ToString() + "','"+ DDeseaseTb.Text+ "')";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query ,con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Doner Successfully Submit. Your request is pending.");
                    con.Close();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void DDeseaseTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void DGenCb_SelectedIndexChanged(object sender, EventArgs e)
        {
          //  string selectedGender = DGenCb.SelectedItem.ToString();


        }

        private void DBGroupCb_SelectedIndexChanged(object sender, EventArgs e)
        {
           // string selectedBloodGroup = DBGroupCb.SelectedItem.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DNameTb.Text = string.Empty;
            DAgeTb.Text = string.Empty;
            DGenCb.SelectedIndex = -1;
            DPhoneTb.Text = string.Empty;
            DBGroupCb.SelectedIndex = -1;
            DDeseaseTb.Text = string.Empty;
            DAddressTb.Text = string.Empty;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            DonorList dl = new DonorList();
            dl.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Recipient recipient = new Recipient();
            recipient.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            RecipientList recipientList = new RecipientList();
            recipientList.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SearchBlood searchblood = new SearchBlood();
            searchblood.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Bloodstock bloodstock = new Bloodstock();
            bloodstock.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Hide();
        }

        private void DNameTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void DAgeTb_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
