﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace BBMS
{
    public partial class SearchBlood : Form
    {
        Function fn = new Function();
        public SearchBlood()
        {
            InitializeComponent();
        }
        
        private void SearchBlood_Load(object sender, EventArgs e)
        {
            String query = "Select from newDonor ";
            DataSet ds = fn.getData(query);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void AddTxt_TextChanged(object sender, EventArgs e)
        {
            if (AddTxt.Text != "")
            {
                string query = "Select = from newDonor where city Like'" + AddTxt.Text + "%'";
                DataSet ds = fn.getData(query);
                dataGridView1.DataSource = ds.Tables[0];
            }
            else
            {
                string query = "Select = from newDonor";
                DataSet ds = fn.getData(query);
                dataGridView1.DataSource = ds.Tables[0];
            }
        }

        private void BloodTxt_TextChanged(object sender, EventArgs e)
        {
            if (BloodTxt.Text != "")
            {
                string query = "Select = from newDonor where city Like'" + BloodTxt.Text + "%'";
                DataSet ds = fn.getData(query);
                dataGridView1.DataSource = ds.Tables[0];
            }
            else
            {
                string query = "Select = from newDonor";
                DataSet ds = fn.getData(query);
                dataGridView1.DataSource = ds.Tables[0];
            }
        }
    }
}
