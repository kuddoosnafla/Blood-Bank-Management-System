﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBMS
{
    internal class Function
    {
        protected SqlConnection GetConnection()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = (@"Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\ADMIN\\Documents\\BBMSDb.mdf;Integrated Security=True;Connect Timeout=30");
            return con;
        }
        public DataSet getData(String query)
        {
        SqlConnection Con = GetConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = Con;
        cmd.CommandText = query;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
            return ds;
        }
    public void SetData(String query)
    {
        SqlConnection con = GetConnection();
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.Open();
        cmd.CommandText = query;
        cmd.ExecuteNonQuery();
        con.Close();
        MessageBox.Show("Data processed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}
}
