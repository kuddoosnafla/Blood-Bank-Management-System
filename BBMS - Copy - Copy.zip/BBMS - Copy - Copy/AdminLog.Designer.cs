﻿namespace BBMS
{
    partial class AdminLog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminLog));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            AdminPssTb = new TextBox();
            label3 = new Label();
            button1 = new Button();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(233, 64);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(94, 88);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(49, 20);
            label1.Name = "label1";
            label1.Size = new Size(464, 32);
            label1.TabIndex = 3;
            label1.Text = "Blood Bank Management System";
            // 
            // AdminPssTb
            // 
            AdminPssTb.Font = new Font("Century Schoolbook", 12F, FontStyle.Regular, GraphicsUnit.Point);
            AdminPssTb.Location = new Point(202, 199);
            AdminPssTb.Name = "AdminPssTb";
            AdminPssTb.Size = new Size(270, 32);
            AdminPssTb.TabIndex = 8;
            AdminPssTb.TextChanged += AdminPssTb_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Century Schoolbook", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.Red;
            label3.Location = new Point(64, 202);
            label3.Name = "label3";
            label3.Size = new Size(98, 23);
            label3.TabIndex = 7;
            label3.Text = "Password";
            // 
            // button1
            // 
            button1.BackColor = Color.IndianRed;
            button1.Font = new Font("Century Schoolbook", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.White;
            button1.Location = new Point(214, 272);
            button1.Name = "button1";
            button1.Size = new Size(204, 43);
            button1.TabIndex = 9;
            button1.Text = "Login";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Century Schoolbook", 13.8F, FontStyle.Underline, GraphicsUnit.Point);
            label2.ForeColor = Color.Red;
            label2.Location = new Point(266, 346);
            label2.Name = "label2";
            label2.Size = new Size(85, 28);
            label2.TabIndex = 10;
            label2.Text = "Cancel";
            label2.Click += label2_Click;
            // 
            // AdminLog
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(571, 406);
            Controls.Add(label2);
            Controls.Add(button1);
            Controls.Add(AdminPssTb);
            Controls.Add(label3);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AdminLog";
            Text = "AdminLog";
            Load += AdminLog_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private TextBox AdminPssTb;
        private Label label3;
        private Button button1;
        private Label label2;
    }
}