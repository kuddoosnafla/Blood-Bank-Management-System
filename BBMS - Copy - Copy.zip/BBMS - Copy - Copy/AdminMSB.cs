﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class AdminMSB : Form
    {
        public AdminMSB()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            AdminDashboard adminDashboard = new AdminDashboard();
            adminDashboard.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            AdminMDL dl = new AdminMDL();
            dl.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            AdminMRL rl = new AdminMRL();
            rl.Show();
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Hide();
        }
    }
}
