﻿namespace BBMS
{
    partial class AdminDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminDashboard));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            label9 = new Label();
            panel9 = new Panel();
            label8 = new Label();
            label7 = new Label();
            label3 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label11 = new Label();
            BPlusNumLbl = new Label();
            APlusProgress = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            APlusNumLbl = new Label();
            label20 = new Label();
            ABPlusNumLbl = new Label();
            label19 = new Label();
            ABPlusProgress = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            OPlusNumLbl = new Label();
            OPlusProgress = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            UserLbl = new Label();
            label16 = new Label();
            TotalLbl = new Label();
            label18 = new Label();
            pictureBox4 = new PictureBox();
            label21 = new Label();
            guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            pictureBox3 = new PictureBox();
            guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            RecipientLbl = new Label();
            label14 = new Label();
            label10 = new Label();
            pictureBox2 = new PictureBox();
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            DonorLbl = new Label();
            BPlusProgress = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            label17 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            APlusProgress.SuspendLayout();
            ABPlusProgress.SuspendLayout();
            OPlusProgress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            guna2GradientPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            guna2GradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            guna2GradientPanel1.SuspendLayout();
            BPlusProgress.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Red;
            panel1.Controls.Add(label9);
            panel1.Controls.Add(panel9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(270, 797);
            panel1.TabIndex = 2;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Red;
            label9.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(81, 688);
            label9.Name = "label9";
            label9.Size = new Size(110, 32);
            label9.TabIndex = 17;
            label9.Text = "Logout";
            label9.Click += label9_Click;
            // 
            // panel9
            // 
            panel9.BackColor = Color.Brown;
            panel9.Location = new Point(31, 179);
            panel9.Name = "panel9";
            panel9.Size = new Size(12, 32);
            panel9.TabIndex = 14;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Red;
            label8.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(49, 179);
            label8.Name = "label8";
            label8.Size = new Size(166, 32);
            label8.TabIndex = 15;
            label8.Text = "Dashboard";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Red;
            label7.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(45, 520);
            label7.Name = "label7";
            label7.Size = new Size(180, 64);
            label7.TabIndex = 13;
            label7.Text = "Manage \r\nBlood Stock";
            label7.Click += label7_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Red;
            label3.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(45, 395);
            label3.Name = "label3";
            label3.Size = new Size(210, 64);
            label3.TabIndex = 5;
            label3.Text = "Manage \r\nRecipient  List";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Red;
            label2.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(49, 273);
            label2.Name = "label2";
            label2.Size = new Size(162, 64);
            label2.TabIndex = 3;
            label2.Text = "Manage\r\nDonor List ";
            label2.Click += label2_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Red;
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(270, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(851, 55);
            panel2.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Red;
            label1.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(219, 9);
            label1.Name = "label1";
            label1.Size = new Size(464, 32);
            label1.TabIndex = 2;
            label1.Text = "Blood Bank Management System";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(649, 119);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(65, 67);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 37;
            pictureBox1.TabStop = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.White;
            label11.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = Color.Red;
            label11.Location = new Point(606, 84);
            label11.Name = "label11";
            label11.Size = new Size(166, 32);
            label11.TabIndex = 36;
            label11.Text = "Dashboard";
            label11.Click += label11_Click;
            // 
            // BPlusNumLbl
            // 
            BPlusNumLbl.AutoSize = true;
            BPlusNumLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            BPlusNumLbl.ForeColor = Color.Red;
            BPlusNumLbl.Location = new Point(48, 50);
            BPlusNumLbl.Name = "BPlusNumLbl";
            BPlusNumLbl.Size = new Size(25, 22);
            BPlusNumLbl.TabIndex = 30;
            BPlusNumLbl.Text = "N";
            // 
            // APlusProgress
            // 
            APlusProgress.Controls.Add(APlusNumLbl);
            APlusProgress.FillColor = Color.FromArgb(200, 213, 218, 223);
            APlusProgress.FillThickness = 10;
            APlusProgress.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            APlusProgress.ForeColor = Color.White;
            APlusProgress.Location = new Point(716, 607);
            APlusProgress.Minimum = 0;
            APlusProgress.Name = "APlusProgress";
            APlusProgress.ProgressColor = Color.Red;
            APlusProgress.ProgressColor2 = Color.Red;
            APlusProgress.ProgressThickness = 10;
            APlusProgress.ShadowDecoration.CustomizableEdges = customizableEdges1;
            APlusProgress.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            APlusProgress.Size = new Size(123, 123);
            APlusProgress.TabIndex = 43;
            APlusProgress.Text = "guna2CircleProgressBar3";
            // 
            // APlusNumLbl
            // 
            APlusNumLbl.AutoSize = true;
            APlusNumLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            APlusNumLbl.ForeColor = Color.Red;
            APlusNumLbl.Location = new Point(48, 50);
            APlusNumLbl.Name = "APlusNumLbl";
            APlusNumLbl.Size = new Size(25, 22);
            APlusNumLbl.TabIndex = 30;
            APlusNumLbl.Text = "N";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.BackColor = Color.White;
            label20.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label20.ForeColor = Color.Red;
            label20.Location = new Point(748, 552);
            label20.Name = "label20";
            label20.Size = new Size(50, 32);
            label20.TabIndex = 48;
            label20.Text = "A+";
            // 
            // ABPlusNumLbl
            // 
            ABPlusNumLbl.AutoSize = true;
            ABPlusNumLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            ABPlusNumLbl.ForeColor = Color.Red;
            ABPlusNumLbl.Location = new Point(48, 50);
            ABPlusNumLbl.Name = "ABPlusNumLbl";
            ABPlusNumLbl.Size = new Size(25, 22);
            ABPlusNumLbl.TabIndex = 30;
            ABPlusNumLbl.Text = "N";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = Color.White;
            label19.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label19.ForeColor = Color.Red;
            label19.Location = new Point(543, 552);
            label19.Name = "label19";
            label19.Size = new Size(70, 32);
            label19.TabIndex = 47;
            label19.Text = "AB+";
            label19.Click += label19_Click;
            // 
            // ABPlusProgress
            // 
            ABPlusProgress.Controls.Add(ABPlusNumLbl);
            ABPlusProgress.FillColor = Color.FromArgb(200, 213, 218, 223);
            ABPlusProgress.FillThickness = 10;
            ABPlusProgress.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ABPlusProgress.ForeColor = Color.White;
            ABPlusProgress.Location = new Point(519, 607);
            ABPlusProgress.Minimum = 0;
            ABPlusProgress.Name = "ABPlusProgress";
            ABPlusProgress.ProgressColor = Color.Red;
            ABPlusProgress.ProgressColor2 = Color.Red;
            ABPlusProgress.ProgressThickness = 10;
            ABPlusProgress.ShadowDecoration.CustomizableEdges = customizableEdges2;
            ABPlusProgress.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            ABPlusProgress.Size = new Size(123, 123);
            ABPlusProgress.TabIndex = 44;
            ABPlusProgress.Text = "guna2CircleProgressBar2";
            // 
            // OPlusNumLbl
            // 
            OPlusNumLbl.AutoSize = true;
            OPlusNumLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            OPlusNumLbl.ForeColor = Color.Red;
            OPlusNumLbl.Location = new Point(51, 50);
            OPlusNumLbl.Name = "OPlusNumLbl";
            OPlusNumLbl.Size = new Size(25, 22);
            OPlusNumLbl.TabIndex = 29;
            OPlusNumLbl.Text = "N";
            // 
            // OPlusProgress
            // 
            OPlusProgress.Controls.Add(OPlusNumLbl);
            OPlusProgress.FillColor = Color.FromArgb(200, 213, 218, 223);
            OPlusProgress.FillThickness = 10;
            OPlusProgress.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            OPlusProgress.ForeColor = Color.White;
            OPlusProgress.Location = new Point(341, 607);
            OPlusProgress.Minimum = 0;
            OPlusProgress.Name = "OPlusProgress";
            OPlusProgress.ProgressColor = Color.Red;
            OPlusProgress.ProgressColor2 = Color.Red;
            OPlusProgress.ProgressThickness = 10;
            OPlusProgress.ShadowDecoration.CustomizableEdges = customizableEdges3;
            OPlusProgress.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            OPlusProgress.Size = new Size(123, 123);
            OPlusProgress.TabIndex = 42;
            OPlusProgress.Text = "guna2CircleProgressBar1";
            // 
            // UserLbl
            // 
            UserLbl.AutoSize = true;
            UserLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            UserLbl.Location = new Point(30, 59);
            UserLbl.Name = "UserLbl";
            UserLbl.Size = new Size(50, 22);
            UserLbl.TabIndex = 28;
            UserLbl.Text = "User";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Century", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label16.Location = new Point(16, 15);
            label16.Name = "label16";
            label16.Size = new Size(64, 28);
            label16.TabIndex = 27;
            label16.Text = "User";
            // 
            // TotalLbl
            // 
            TotalLbl.AutoSize = true;
            TotalLbl.BackColor = Color.White;
            TotalLbl.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            TotalLbl.ForeColor = Color.Red;
            TotalLbl.Location = new Point(649, 483);
            TotalLbl.Name = "TotalLbl";
            TotalLbl.Size = new Size(84, 32);
            TotalLbl.TabIndex = 50;
            TotalLbl.Text = "Total";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.BackColor = Color.White;
            label18.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label18.ForeColor = Color.Red;
            label18.Location = new Point(375, 552);
            label18.Name = "label18";
            label18.Size = new Size(52, 32);
            label18.TabIndex = 46;
            label18.Text = "O+";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(112, 3);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(82, 91);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 26;
            pictureBox4.TabStop = false;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.BackColor = Color.White;
            label21.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label21.ForeColor = Color.Red;
            label21.Location = new Point(937, 552);
            label21.Name = "label21";
            label21.Size = new Size(50, 32);
            label21.TabIndex = 49;
            label21.Text = "B+";
            // 
            // guna2GradientPanel3
            // 
            guna2GradientPanel3.BackColor = Color.Salmon;
            guna2GradientPanel3.Controls.Add(UserLbl);
            guna2GradientPanel3.Controls.Add(label16);
            guna2GradientPanel3.Controls.Add(pictureBox4);
            guna2GradientPanel3.CustomizableEdges = customizableEdges4;
            guna2GradientPanel3.Location = new Point(856, 243);
            guna2GradientPanel3.Name = "guna2GradientPanel3";
            guna2GradientPanel3.ShadowDecoration.CustomizableEdges = customizableEdges5;
            guna2GradientPanel3.Size = new Size(198, 97);
            guna2GradientPanel3.TabIndex = 40;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(137, 4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(82, 90);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 26;
            pictureBox3.TabStop = false;
            // 
            // guna2GradientPanel2
            // 
            guna2GradientPanel2.BackColor = Color.Salmon;
            guna2GradientPanel2.Controls.Add(RecipientLbl);
            guna2GradientPanel2.Controls.Add(label14);
            guna2GradientPanel2.Controls.Add(pictureBox3);
            guna2GradientPanel2.CustomizableEdges = customizableEdges6;
            guna2GradientPanel2.Location = new Point(572, 243);
            guna2GradientPanel2.Name = "guna2GradientPanel2";
            guna2GradientPanel2.ShadowDecoration.CustomizableEdges = customizableEdges7;
            guna2GradientPanel2.Size = new Size(226, 97);
            guna2GradientPanel2.TabIndex = 39;
            guna2GradientPanel2.Paint += guna2GradientPanel2_Paint;
            // 
            // RecipientLbl
            // 
            RecipientLbl.AutoSize = true;
            RecipientLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            RecipientLbl.Location = new Point(37, 59);
            RecipientLbl.Name = "RecipientLbl";
            RecipientLbl.Size = new Size(89, 22);
            RecipientLbl.TabIndex = 28;
            RecipientLbl.Text = "Recipient";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Century", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(13, 15);
            label14.Name = "label14";
            label14.Size = new Size(113, 28);
            label14.TabIndex = 27;
            label14.Text = "Recipient";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(16, 15);
            label10.Name = "label10";
            label10.Size = new Size(78, 28);
            label10.TabIndex = 27;
            label10.Text = "Donor";
            label10.Click += label10_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(112, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(82, 91);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 26;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.BackColor = Color.Salmon;
            guna2GradientPanel1.Controls.Add(DonorLbl);
            guna2GradientPanel1.Controls.Add(label10);
            guna2GradientPanel1.Controls.Add(pictureBox2);
            guna2GradientPanel1.CustomizableEdges = customizableEdges8;
            guna2GradientPanel1.Location = new Point(320, 243);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges9;
            guna2GradientPanel1.Size = new Size(198, 97);
            guna2GradientPanel1.TabIndex = 38;
            guna2GradientPanel1.Paint += guna2GradientPanel1_Paint;
            // 
            // DonorLbl
            // 
            DonorLbl.AutoSize = true;
            DonorLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            DonorLbl.Location = new Point(33, 59);
            DonorLbl.Name = "DonorLbl";
            DonorLbl.Size = new Size(61, 22);
            DonorLbl.TabIndex = 28;
            DonorLbl.Text = "Donor";
            DonorLbl.Click += DonorLbl_Click;
            // 
            // BPlusProgress
            // 
            BPlusProgress.Controls.Add(BPlusNumLbl);
            BPlusProgress.FillColor = Color.FromArgb(200, 213, 218, 223);
            BPlusProgress.FillThickness = 10;
            BPlusProgress.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            BPlusProgress.ForeColor = Color.White;
            BPlusProgress.Location = new Point(907, 607);
            BPlusProgress.Minimum = 0;
            BPlusProgress.Name = "BPlusProgress";
            BPlusProgress.ProgressColor = Color.Red;
            BPlusProgress.ProgressColor2 = Color.Red;
            BPlusProgress.ProgressThickness = 10;
            BPlusProgress.ShadowDecoration.CustomizableEdges = customizableEdges10;
            BPlusProgress.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            BPlusProgress.Size = new Size(123, 123);
            BPlusProgress.TabIndex = 45;
            BPlusProgress.Text = "guna2CircleProgressBar4";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.White;
            label17.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor = Color.Red;
            label17.Location = new Point(592, 440);
            label17.Name = "label17";
            label17.Size = new Size(180, 32);
            label17.TabIndex = 41;
            label17.Text = "Blood Stock";
            // 
            // AdminDashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1121, 797);
            Controls.Add(APlusProgress);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(ABPlusProgress);
            Controls.Add(OPlusProgress);
            Controls.Add(TotalLbl);
            Controls.Add(label18);
            Controls.Add(label21);
            Controls.Add(guna2GradientPanel3);
            Controls.Add(guna2GradientPanel2);
            Controls.Add(guna2GradientPanel1);
            Controls.Add(BPlusProgress);
            Controls.Add(label17);
            Controls.Add(pictureBox1);
            Controls.Add(label11);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "AdminDashboard";
            Text = "AdminDashboard";
            Load += AdminDashboard_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            APlusProgress.ResumeLayout(false);
            APlusProgress.PerformLayout();
            ABPlusProgress.ResumeLayout(false);
            ABPlusProgress.PerformLayout();
            OPlusProgress.ResumeLayout(false);
            OPlusProgress.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            guna2GradientPanel3.ResumeLayout(false);
            guna2GradientPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            guna2GradientPanel2.ResumeLayout(false);
            guna2GradientPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            guna2GradientPanel1.ResumeLayout(false);
            guna2GradientPanel1.PerformLayout();
            BPlusProgress.ResumeLayout(false);
            BPlusProgress.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label9;
        private Panel panel9;
        private Label label8;
        private Label label7;
        private Label label3;
        private Label label2;
        private Panel panel2;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label11;
        private Label BPlusNumLbl;
        private Guna.UI2.WinForms.Guna2CircleProgressBar APlusProgress;
        private Label APlusNumLbl;
        private Label label20;
        private Label ABPlusNumLbl;
        private Label label19;
        private Guna.UI2.WinForms.Guna2CircleProgressBar ABPlusProgress;
        private Label OPlusNumLbl;
        private Guna.UI2.WinForms.Guna2CircleProgressBar OPlusProgress;
        private Label UserLbl;
        private Label label16;
        private Label TotalLbl;
        private Label label18;
        private PictureBox pictureBox4;
        private Label label21;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private PictureBox pictureBox3;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Label RecipientLbl;
        private Label label14;
        private Label label10;
        private PictureBox pictureBox2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Label DonorLbl;
        private Guna.UI2.WinForms.Guna2CircleProgressBar BPlusProgress;
        private Label label17;
    }
}