﻿namespace BBMS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button1 = new Button();
            pictureBox1 = new PictureBox();
            Myprogress = new CircularProgressBar.CircularProgressBar();
            label1 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.White;
            button1.Location = new Point(205, 373);
            button1.Name = "button1";
            button1.Size = new Size(126, 41);
            button1.TabIndex = 7;
            button1.Text = "Start";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Gainsboro;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(205, 163);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(126, 119);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // Myprogress
            // 
            Myprogress.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            Myprogress.AnimationSpeed = 500;
            Myprogress.BackColor = Color.White;
            Myprogress.Font = new Font("Segoe UI", 72F, FontStyle.Bold, GraphicsUnit.Point);
            Myprogress.ForeColor = Color.White;
            Myprogress.InnerColor = Color.FromArgb(224, 224, 224);
            Myprogress.InnerMargin = 2;
            Myprogress.InnerWidth = -1;
            Myprogress.Location = new Point(124, 95);
            Myprogress.MarqueeAnimationSpeed = 2000;
            Myprogress.Name = "Myprogress";
            Myprogress.OuterColor = Color.LightGray;
            Myprogress.OuterMargin = -25;
            Myprogress.OuterWidth = 26;
            Myprogress.ProgressColor = Color.Red;
            Myprogress.ProgressWidth = 18;
            Myprogress.SecondaryFont = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point);
            Myprogress.Size = new Size(286, 272);
            Myprogress.StartAngle = 270;
            Myprogress.Style = ProgressBarStyle.Continuous;
            Myprogress.SubscriptColor = Color.FromArgb(166, 166, 166);
            Myprogress.SubscriptMargin = new Padding(10, -35, 0, 0);
            Myprogress.SubscriptText = ".23";
            Myprogress.SuperscriptColor = Color.FromArgb(166, 166, 166);
            Myprogress.SuperscriptMargin = new Padding(10, 35, 0, 0);
            Myprogress.SuperscriptText = "";
            Myprogress.TabIndex = 5;
            Myprogress.TextMargin = new Padding(8, 8, 0, 0);
            Myprogress.Value = 68;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(37, 30);
            label1.Name = "label1";
            label1.Size = new Size(464, 32);
            label1.TabIndex = 4;
            label1.Text = "Blood Bank Management System";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(541, 450);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Controls.Add(Myprogress);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private PictureBox pictureBox1;
        private CircularProgressBar.CircularProgressBar Myprogress;
        private Label label1;
        private System.Windows.Forms.Timer timer1;
    }
}