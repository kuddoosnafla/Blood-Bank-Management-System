﻿CREATE TABLE [dbo].[DonorTbl]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [RNameTb] NCHAR(50) NOT NULL, 
    [RAgeTb] NCHAR(20) NOT NULL, 
    [RPhoneTb] INT NOT NULL, 
    [RAddressTb] NCHAR(50) NOT NULL, 
    [RGenCb] NCHAR(50) NOT NULL, 
    [RBGroupCb] NCHAR(20) NOT NULL
)
