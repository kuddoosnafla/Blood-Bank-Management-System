﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBMS
{
    public partial class Recipient : Form
    {
        public Recipient()
        {
            InitializeComponent();

            RGenCb.Items.Add("Male");
            RGenCb.Items.Add("Female");
            RGenCb.Items.Add("Other");
            RGenCb.SelectedIndex = 0;


            RBGroupCb.Items.Add("A+");
            RBGroupCb.Items.Add("A-");
            RBGroupCb.Items.Add("B+");
            RBGroupCb.Items.Add("B-");
            RBGroupCb.Items.Add("AB+");
            RBGroupCb.Items.Add("AB-");
            RBGroupCb.Items.Add("O+");
            RBGroupCb.Items.Add("O-");

            RBGroupCb.SelectedIndex = 0;
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\BloodBankManagDB.mdf;Integrated Security=True;Connect Timeout=30");

        private void Reset()
        {
            RNameTb.Text = "";
            RAgeTb.Text = "";
            RPhoneTb.Text = "";
            RAddressTb.Text = "";
            RGenCb.SelectedIndex = -1;
            RBGroupCb.SelectedIndex = -1;

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void Recipient_Load(object sender, EventArgs e)
        {
        }

        private void panel9_Paint(object sender, PaintEventArgs e)
        {
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Doner doner = new Doner();
            doner.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            DonorList dl = new DonorList();
            dl.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            RecipientList recipientList = new RecipientList();
            recipientList.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            SearchBlood searchblood = new SearchBlood();
            searchblood.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Bloodstock bloodstock = new Bloodstock();
            bloodstock.Show();
            this.Hide();
        }

        private void label10_Click_1(object sender, EventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RNameTb.Text = string.Empty;
            RAgeTb.Text = string.Empty;
            RGenCb.SelectedIndex = -1;
            RPhoneTb.Text = string.Empty;
            RBGroupCb.SelectedIndex = -1;
            RAddressTb.Text = string.Empty;
           
        }

        private void RGenCb_SelectedIndexChanged(object sender, EventArgs e)
        {
            // string selectedGender = RGenCb.SelectedItem.ToString();
        }

        private void RBGroupCb_SelectedIndexChanged(object sender, EventArgs e)
        {
            // string selectedBloodGroup = RBGroupCb.SelectedItem.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (RNameTb.Text == "" || RPhoneTb.Text == "" || RAgeTb.Text == "" || RGenCb.SelectedIndex == -1 || RBGroupCb.SelectedIndex == -1 || RAddressTb.Text == "" )
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    string query = "insert into RacipientTbl values('" + RNameTb.Text + "','" + RAgeTb.Text + "','" + RGenCb.SelectedItem.ToString() + "','" + RPhoneTb.Text + "','" + RAddressTb.Text + "','" + RBGroupCb.SelectedItem.ToString() + "')";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Racipient Successfully Submit. ");
                    con.Close();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void RNameTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void RAddressTb_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
