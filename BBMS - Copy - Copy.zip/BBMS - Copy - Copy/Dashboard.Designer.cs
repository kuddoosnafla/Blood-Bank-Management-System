﻿namespace BBMS
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            label9 = new Label();
            panel9 = new Panel();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            panel2 = new Panel();
            label1 = new Label();
            label11 = new Label();
            pictureBox1 = new PictureBox();
            guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            DonorLbl = new Label();
            label10 = new Label();
            pictureBox2 = new PictureBox();
            guna2GradientPanel2 = new Guna.UI2.WinForms.Guna2GradientPanel();
            RecipientLbl = new Label();
            label14 = new Label();
            pictureBox3 = new PictureBox();
            guna2GradientPanel3 = new Guna.UI2.WinForms.Guna2GradientPanel();
            UserLbl = new Label();
            label16 = new Label();
            pictureBox4 = new PictureBox();
            label17 = new Label();
            OPlusProgress = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            OPlusNumLbl = new Label();
            ABPlusProgress = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            ABPlusNumLbl = new Label();
            APlusProgress = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            APlusNumLbl = new Label();
            BPlusProgress = new Guna.UI2.WinForms.Guna2CircleProgressBar();
            BPlusNumLbl = new Label();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            TotalLbl = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            guna2GradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            guna2GradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            guna2GradientPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            OPlusProgress.SuspendLayout();
            ABPlusProgress.SuspendLayout();
            APlusProgress.SuspendLayout();
            BPlusProgress.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Red;
            panel1.Controls.Add(label9);
            panel1.Controls.Add(panel9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(251, 744);
            panel1.TabIndex = 1;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Red;
            label9.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(81, 671);
            label9.Name = "label9";
            label9.Size = new Size(110, 32);
            label9.TabIndex = 17;
            label9.Text = "Logout";
            label9.Click += label9_Click;
            // 
            // panel9
            // 
            panel9.BackColor = Color.Brown;
            panel9.Location = new Point(27, 106);
            panel9.Name = "panel9";
            panel9.Size = new Size(12, 32);
            panel9.TabIndex = 14;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Red;
            label8.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(45, 106);
            label8.Name = "label8";
            label8.Size = new Size(166, 32);
            label8.TabIndex = 15;
            label8.Text = "Dashboard";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Red;
            label7.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(45, 496);
            label7.Name = "label7";
            label7.Size = new Size(180, 32);
            label7.TabIndex = 13;
            label7.Text = "Blood Stock";
            label7.Click += label7_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Red;
            label6.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(45, 426);
            label6.Name = "label6";
            label6.Size = new Size(200, 32);
            label6.TabIndex = 11;
            label6.Text = "Search Blood";
            label6.Click += label6_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Red;
            label5.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(45, 357);
            label5.Name = "label5";
            label5.Size = new Size(203, 32);
            label5.TabIndex = 9;
            label5.Text = "Recipient List";
            label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Red;
            label4.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(45, 291);
            label4.Name = "label4";
            label4.Size = new Size(146, 32);
            label4.TabIndex = 7;
            label4.Text = "Recipient";
            label4.Click += label4_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Red;
            label3.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(46, 226);
            label3.Name = "label3";
            label3.Size = new Size(162, 32);
            label3.TabIndex = 5;
            label3.Text = "Donor  List";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Red;
            label2.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(45, 166);
            label2.Name = "label2";
            label2.Size = new Size(105, 32);
            label2.TabIndex = 3;
            label2.Text = "Donor ";
            label2.Click += label2_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Red;
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(251, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(863, 55);
            panel2.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Red;
            label1.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(219, 9);
            label1.Name = "label1";
            label1.Size = new Size(464, 32);
            label1.TabIndex = 2;
            label1.Text = "Blood Bank Management System";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.White;
            label11.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = Color.Red;
            label11.Location = new Point(603, 86);
            label11.Name = "label11";
            label11.Size = new Size(166, 32);
            label11.TabIndex = 24;
            label11.Text = "Dashboard";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(648, 121);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(65, 67);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 25;
            pictureBox1.TabStop = false;
            // 
            // guna2GradientPanel1
            // 
            guna2GradientPanel1.BackColor = Color.Salmon;
            guna2GradientPanel1.Controls.Add(DonorLbl);
            guna2GradientPanel1.Controls.Add(label10);
            guna2GradientPanel1.Controls.Add(pictureBox2);
            guna2GradientPanel1.CustomizableEdges = customizableEdges1;
            guna2GradientPanel1.Location = new Point(316, 226);
            guna2GradientPanel1.Name = "guna2GradientPanel1";
            guna2GradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2GradientPanel1.Size = new Size(198, 97);
            guna2GradientPanel1.TabIndex = 26;
            // 
            // DonorLbl
            // 
            DonorLbl.AutoSize = true;
            DonorLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            DonorLbl.Location = new Point(34, 59);
            DonorLbl.Name = "DonorLbl";
            DonorLbl.Size = new Size(61, 22);
            DonorLbl.TabIndex = 28;
            DonorLbl.Text = "Donor";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Century", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(17, 15);
            label10.Name = "label10";
            label10.Size = new Size(78, 28);
            label10.TabIndex = 27;
            label10.Text = "Donor";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(113, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(82, 91);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 26;
            pictureBox2.TabStop = false;
            // 
            // guna2GradientPanel2
            // 
            guna2GradientPanel2.BackColor = Color.Salmon;
            guna2GradientPanel2.Controls.Add(RecipientLbl);
            guna2GradientPanel2.Controls.Add(label14);
            guna2GradientPanel2.Controls.Add(pictureBox3);
            guna2GradientPanel2.CustomizableEdges = customizableEdges3;
            guna2GradientPanel2.Location = new Point(578, 226);
            guna2GradientPanel2.Name = "guna2GradientPanel2";
            guna2GradientPanel2.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2GradientPanel2.Size = new Size(226, 97);
            guna2GradientPanel2.TabIndex = 27;
            // 
            // RecipientLbl
            // 
            RecipientLbl.AutoSize = true;
            RecipientLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            RecipientLbl.Location = new Point(41, 59);
            RecipientLbl.Name = "RecipientLbl";
            RecipientLbl.Size = new Size(89, 22);
            RecipientLbl.TabIndex = 28;
            RecipientLbl.Text = "Recipient";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Century", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(17, 15);
            label14.Name = "label14";
            label14.Size = new Size(113, 28);
            label14.TabIndex = 27;
            label14.Text = "Recipient";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(141, 4);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(82, 90);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 26;
            pictureBox3.TabStop = false;
            // 
            // guna2GradientPanel3
            // 
            guna2GradientPanel3.BackColor = Color.Salmon;
            guna2GradientPanel3.Controls.Add(UserLbl);
            guna2GradientPanel3.Controls.Add(label16);
            guna2GradientPanel3.Controls.Add(pictureBox4);
            guna2GradientPanel3.CustomizableEdges = customizableEdges5;
            guna2GradientPanel3.Location = new Point(870, 226);
            guna2GradientPanel3.Name = "guna2GradientPanel3";
            guna2GradientPanel3.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2GradientPanel3.Size = new Size(198, 97);
            guna2GradientPanel3.TabIndex = 28;
            // 
            // UserLbl
            // 
            UserLbl.AutoSize = true;
            UserLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            UserLbl.Location = new Point(31, 59);
            UserLbl.Name = "UserLbl";
            UserLbl.Size = new Size(50, 22);
            UserLbl.TabIndex = 28;
            UserLbl.Text = "User";
            UserLbl.Click += label15_Click;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Century", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label16.Location = new Point(17, 15);
            label16.Name = "label16";
            label16.Size = new Size(64, 28);
            label16.TabIndex = 27;
            label16.Text = "User";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(113, 3);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(82, 91);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 26;
            pictureBox4.TabStop = false;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.White;
            label17.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor = Color.Red;
            label17.Location = new Point(603, 394);
            label17.Name = "label17";
            label17.Size = new Size(180, 32);
            label17.TabIndex = 29;
            label17.Text = "Blood Stock";
            // 
            // OPlusProgress
            // 
            OPlusProgress.Controls.Add(OPlusNumLbl);
            OPlusProgress.FillColor = Color.FromArgb(200, 213, 218, 223);
            OPlusProgress.FillThickness = 10;
            OPlusProgress.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            OPlusProgress.ForeColor = Color.White;
            OPlusProgress.Location = new Point(316, 557);
            OPlusProgress.Minimum = 0;
            OPlusProgress.Name = "OPlusProgress";
            OPlusProgress.ProgressColor = Color.Red;
            OPlusProgress.ProgressColor2 = Color.Red;
            OPlusProgress.ProgressThickness = 10;
            OPlusProgress.ShadowDecoration.CustomizableEdges = customizableEdges7;
            OPlusProgress.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            OPlusProgress.Size = new Size(123, 123);
            OPlusProgress.TabIndex = 30;
            OPlusProgress.Text = "guna2CircleProgressBar1";
            OPlusProgress.ValueChanged += OPlusProgress_ValueChanged;
            // 
            // OPlusNumLbl
            // 
            OPlusNumLbl.AutoSize = true;
            OPlusNumLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            OPlusNumLbl.ForeColor = Color.Red;
            OPlusNumLbl.Location = new Point(52, 50);
            OPlusNumLbl.Name = "OPlusNumLbl";
            OPlusNumLbl.Size = new Size(25, 22);
            OPlusNumLbl.TabIndex = 29;
            OPlusNumLbl.Text = "N";
            // 
            // ABPlusProgress
            // 
            ABPlusProgress.Controls.Add(ABPlusNumLbl);
            ABPlusProgress.FillColor = Color.FromArgb(200, 213, 218, 223);
            ABPlusProgress.FillThickness = 10;
            ABPlusProgress.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            ABPlusProgress.ForeColor = Color.White;
            ABPlusProgress.Location = new Point(527, 557);
            ABPlusProgress.Minimum = 0;
            ABPlusProgress.Name = "ABPlusProgress";
            ABPlusProgress.ProgressColor = Color.Red;
            ABPlusProgress.ProgressColor2 = Color.Red;
            ABPlusProgress.ProgressThickness = 10;
            ABPlusProgress.ShadowDecoration.CustomizableEdges = customizableEdges8;
            ABPlusProgress.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            ABPlusProgress.Size = new Size(123, 123);
            ABPlusProgress.TabIndex = 31;
            ABPlusProgress.Text = "guna2CircleProgressBar2";
            // 
            // ABPlusNumLbl
            // 
            ABPlusNumLbl.AutoSize = true;
            ABPlusNumLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            ABPlusNumLbl.ForeColor = Color.Red;
            ABPlusNumLbl.Location = new Point(49, 50);
            ABPlusNumLbl.Name = "ABPlusNumLbl";
            ABPlusNumLbl.Size = new Size(25, 22);
            ABPlusNumLbl.TabIndex = 30;
            ABPlusNumLbl.Text = "N";
            // 
            // APlusProgress
            // 
            APlusProgress.Controls.Add(APlusNumLbl);
            APlusProgress.FillColor = Color.FromArgb(200, 213, 218, 223);
            APlusProgress.FillThickness = 10;
            APlusProgress.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            APlusProgress.ForeColor = Color.White;
            APlusProgress.Location = new Point(734, 557);
            APlusProgress.Minimum = 0;
            APlusProgress.Name = "APlusProgress";
            APlusProgress.ProgressColor = Color.Red;
            APlusProgress.ProgressColor2 = Color.Red;
            APlusProgress.ProgressThickness = 10;
            APlusProgress.ShadowDecoration.CustomizableEdges = customizableEdges9;
            APlusProgress.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            APlusProgress.Size = new Size(123, 123);
            APlusProgress.TabIndex = 31;
            APlusProgress.Text = "guna2CircleProgressBar3";
            // 
            // APlusNumLbl
            // 
            APlusNumLbl.AutoSize = true;
            APlusNumLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            APlusNumLbl.ForeColor = Color.Red;
            APlusNumLbl.Location = new Point(49, 50);
            APlusNumLbl.Name = "APlusNumLbl";
            APlusNumLbl.Size = new Size(25, 22);
            APlusNumLbl.TabIndex = 30;
            APlusNumLbl.Text = "N";
            // 
            // BPlusProgress
            // 
            BPlusProgress.Controls.Add(BPlusNumLbl);
            BPlusProgress.FillColor = Color.FromArgb(200, 213, 218, 223);
            BPlusProgress.FillThickness = 10;
            BPlusProgress.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            BPlusProgress.ForeColor = Color.White;
            BPlusProgress.Location = new Point(942, 557);
            BPlusProgress.Minimum = 0;
            BPlusProgress.Name = "BPlusProgress";
            BPlusProgress.ProgressColor = Color.Red;
            BPlusProgress.ProgressColor2 = Color.Red;
            BPlusProgress.ProgressThickness = 10;
            BPlusProgress.ShadowDecoration.CustomizableEdges = customizableEdges10;
            BPlusProgress.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            BPlusProgress.Size = new Size(123, 123);
            BPlusProgress.TabIndex = 31;
            BPlusProgress.Text = "guna2CircleProgressBar4";
            // 
            // BPlusNumLbl
            // 
            BPlusNumLbl.AutoSize = true;
            BPlusNumLbl.Font = new Font("Century", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            BPlusNumLbl.ForeColor = Color.Red;
            BPlusNumLbl.Location = new Point(49, 50);
            BPlusNumLbl.Name = "BPlusNumLbl";
            BPlusNumLbl.Size = new Size(25, 22);
            BPlusNumLbl.TabIndex = 30;
            BPlusNumLbl.Text = "N";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.BackColor = Color.White;
            label18.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label18.ForeColor = Color.Red;
            label18.Location = new Point(359, 509);
            label18.Name = "label18";
            label18.Size = new Size(52, 32);
            label18.TabIndex = 32;
            label18.Text = "O+";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = Color.White;
            label19.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label19.ForeColor = Color.Red;
            label19.Location = new Point(550, 509);
            label19.Name = "label19";
            label19.Size = new Size(70, 32);
            label19.TabIndex = 33;
            label19.Text = "AB+";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.BackColor = Color.White;
            label20.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label20.ForeColor = Color.Red;
            label20.Location = new Point(763, 509);
            label20.Name = "label20";
            label20.Size = new Size(50, 32);
            label20.TabIndex = 34;
            label20.Text = "A+";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.BackColor = Color.White;
            label21.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label21.ForeColor = Color.Red;
            label21.Location = new Point(973, 509);
            label21.Name = "label21";
            label21.Size = new Size(50, 32);
            label21.TabIndex = 35;
            label21.Text = "B+";
            // 
            // TotalLbl
            // 
            TotalLbl.AutoSize = true;
            TotalLbl.BackColor = Color.White;
            TotalLbl.Font = new Font("Arial Rounded MT Bold", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            TotalLbl.ForeColor = Color.Red;
            TotalLbl.Location = new Point(660, 437);
            TotalLbl.Name = "TotalLbl";
            TotalLbl.Size = new Size(84, 32);
            TotalLbl.TabIndex = 36;
            TotalLbl.Text = "Total";
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1114, 744);
            Controls.Add(TotalLbl);
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(APlusProgress);
            Controls.Add(BPlusProgress);
            Controls.Add(ABPlusProgress);
            Controls.Add(OPlusProgress);
            Controls.Add(label17);
            Controls.Add(guna2GradientPanel3);
            Controls.Add(guna2GradientPanel2);
            Controls.Add(guna2GradientPanel1);
            Controls.Add(pictureBox1);
            Controls.Add(label11);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Dashboard";
            Text = "Dashboard";
            Load += Dashboard_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            guna2GradientPanel1.ResumeLayout(false);
            guna2GradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            guna2GradientPanel2.ResumeLayout(false);
            guna2GradientPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            guna2GradientPanel3.ResumeLayout(false);
            guna2GradientPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            OPlusProgress.ResumeLayout(false);
            OPlusProgress.PerformLayout();
            ABPlusProgress.ResumeLayout(false);
            ABPlusProgress.PerformLayout();
            APlusProgress.ResumeLayout(false);
            APlusProgress.PerformLayout();
            BPlusProgress.ResumeLayout(false);
            BPlusProgress.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label9;
        private Panel panel9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Panel panel2;
        private Label label1;
        private Label label11;
        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Label DonorLbl;
        private Label label10;
        private PictureBox pictureBox2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel2;
        private Label RecipientLbl;
        private Label label14;
        private PictureBox pictureBox3;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel3;
        private Label UserLbl;
        private Label label16;
        private PictureBox pictureBox4;
        private Label label17;
        private Guna.UI2.WinForms.Guna2CircleProgressBar OPlusProgress;
        private Guna.UI2.WinForms.Guna2CircleProgressBar ABPlusProgress;
        private Guna.UI2.WinForms.Guna2CircleProgressBar APlusProgress;
        private Guna.UI2.WinForms.Guna2CircleProgressBar BPlusProgress;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label OPlusNumLbl;
        private Label TotalLbl;
        private Label ABPlusNumLbl;
        private Label APlusNumLbl;
        private Label BPlusNumLbl;
    }
}